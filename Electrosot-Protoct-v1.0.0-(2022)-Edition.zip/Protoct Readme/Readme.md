# Electrosoft Protoct v1.0.0 (2022) Edition

This is a antivirus software by "ELECTROSOFT"

There are two archives extract any one archive in all the folders you have because you have extract protoct in every folder you create or in already existing folder

When you extract in every folder only it will detect virus in that folder

Thank you!!!
